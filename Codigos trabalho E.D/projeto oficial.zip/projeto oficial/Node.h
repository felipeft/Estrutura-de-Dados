#ifndef NODE_H
#define NODE_H

typedef int Item;

struct Node{
    Item data;
    Node *ant;
    Node *prox;

    Node(const Item& d, Node *a, Node *p){
        data = d;
        ant = a;
        prox = p;
    }
};


#endif
