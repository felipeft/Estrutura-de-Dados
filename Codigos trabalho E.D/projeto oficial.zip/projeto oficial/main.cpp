#include <iostream>
#include "List.h"
using namespace std;

int main(){
    List l;
    cout << "começo da lista: " << l.front() << endl;
    cout << "fim da lista: " << l.back() << endl;
    cout << "tamanho da lista: " << l.size() << endl;
}