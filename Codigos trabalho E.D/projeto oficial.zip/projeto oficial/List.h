#ifndef LIST_H
#define LIST_H
#include "Node.h";
#include <stdexcept>

class List{

private:
    Node *inicio;
    Node *fim;
    int tam;

public:
    List();                                     //1ª
    List(const List& lst);                      //2ª
    ~List();                                    //3ª
    bool empty() const;                         //4ª
    size_t size() const;                        //5ª
    void clear();                               //6ª
    Item front();                               //7ª
    Item back();                                //8ª  
    void push_front(const Item& data);          //9ª          
    void push_back(const Item& data);           //10ª
    void pop_front();                           //11ª
    void pop_back();                            //12ª
    void insertAt(const Item& data, int index); //13ª
    void removeAt(int index);                   //14ª
    
    void printAll();
    
};

List::List(){
    tam = 0;
    inicio = nullptr;
    fim = nullptr;
}

List::List(const List& lst){
    tam = lst.tam;
    inicio = lst.inicio;
    fim = lst.fim;
}

List::~List(){
    clear();
}

bool List::empty() const{
    return inicio == fim;
}

size_t List::size() const{
    return tam;
}

void List::clear(){
    while(inicio != fim){
        Node *aux = inicio;
        inicio = inicio->prox;
        delete aux;
    }
}

Item List::front(){
    return inicio->data;
}

Item List::back(){
    return fim->data;
}

void List::push_front(const Item& data){
    Node *newNode = new Node(data, nullptr, nullptr);
    if(newNode){
        //case 1: se a lista estiver vazia
        if(inicio == nullptr){
            tam++;
            inicio = newNode;
            fim = newNode;
        }
        //case 2: se a lista ja tiver 1 elemento
        else if(tam == 1){
            inicio->ant = newNode;
            inicio->prox = newNode;
            inicio = newNode;
            newNode->prox = fim;
            newNode->ant = fim;
            tam++;
        }
        //case 3: se a lista ja tiver mais de 2 elementos
        else{
            inicio->ant = newNode;
            newNode->prox = inicio;
            inicio = newNode;
            newNode->ant = fim;
            fim->prox = newNode;
            tam++;
        }
    }else{
        throw std::underflow_error("nao foi possivel alocar memoria.");
    }
}

void List::push_back(const Item& data){
    Node *newNode = new Node(data, nullptr, nullptr);
    if(newNode){
        //case 1: se a lista estiver vazia
        if(inicio == nullptr){
            tam++;
            inicio = newNode;
            fim = newNode;
        }
        //case 2: se a lista ja tiver 1 elemento
        else if(tam == 1){
            inicio->prox = newNode;
            inicio->ant = newNode;
            fim = newNode;
            newNode->ant = inicio;
            newNode->prox = inicio;
            tam++;
        }
        //case 3: se a lista ja tem mais de 2 elementos
        else{
            inicio->ant  = newNode;
            newNode->prox = inicio;
            newNode->ant = fim;
            fim->prox = newNode;
            fim = newNode;
            tam++;
        }
    }else{
        throw std::underflow_error("nao foi possivel alocar memoria.");
    }
}

void List::pop_front(){
    if(tam == 0){
        throw std::underflow_error("a lista esta vazia!");
    }
    else if(tam == 1){
        clear();
        throw std::underflow_error("a lista esta vazia!");
    }
    else{
        Node *aux = inicio;
        inicio = inicio->prox;
        inicio->ant = fim;
        delete aux;
        aux = nullptr;
        tam--;
    }
}

void List::pop_back(){
    if(tam == 0){
        throw std::underflow_error("a lista esta vazia!");
    }
    else if(tam == 1){
        clear();
        throw std::underflow_error("a lista esta vazia!");
    }
    else{
        Node *aux = fim;
        fim = fim->ant;
        fim->prox = inicio;
        inicio->ant = fim;
        delete aux;
        aux = nullptr;
        tam--; 
    }
}

void List::insertAt(const Item& data, int index){
    if(index > tam){
        throw std::underflow_error("nao é possivel adicionar um elemento a esta posiçao.");
    }else{
        //faremos 3 casos possiveis, e se o usuario deseja adicionar ao começo da lista, ao final ou ao meio
        //case 1: usuario deseja adicionar ao começo da lista;
        if(index == 0){
            push_front(data);
        }
        //case 2: caso o usuario deseja adicionar ao final da lista
        else if(index == tam){
            push_back(data);
        }
        //case 3: caso o usuario deseje adicionar no meio da lista na posicao de sua preferencia
        else{
            Node *newNode = new Node(data, nullptr, nullptr);
            Node *aux = inicio;
            for(int i=0; i<index; i++){
            aux = aux->prox;
        }
        Node *aux2 = inicio;
        for(int i=0; i<index-1; i++){
            aux2 = aux2->prox;
        }
        tam++;
        newNode->prox = aux;
        aux->ant = newNode;
        aux2->prox = newNode;
        newNode->ant = aux2;
        }
    }
}

void List::removeAt(int index){
    if(index > tam-1){
        throw std::underflow_error("nao ha nada nessa posicao, nao é possivel remover.");
    }else{
        //case 1: caso a lista so tenha 1 elemento;
        if(tam == 1){
            pop_front();
        }
        //case 2: caso o usuario deseje remover o primeiro elemento
        else if(index == 0){
            pop_front();
        }
        //case 3: caso o usuario deseje remover o ultimo elemento
        else if(index == tam-1){
            pop_back();
        }
        //case 4: caso o usuario deseje remover um elemento do meio da lista qualquer
        else{
            Node *aux = inicio;
            for(int i=0; i<index; i++){
                aux = aux->prox;
            }

            Node *aux2 = inicio;
            for(int i=0; i<index-1; i++){
                aux2 = aux2->prox;
            }
            aux2->prox = aux->prox;
            aux->prox = aux2;
            delete aux;
            aux = nullptr;
            tam--;
        }
    }
}

void List::printAll(){
    Node *aux = inicio;
    std::cout << "[ ";
    int copy_tam = tam;
    while(copy_tam != 0){
        std::cout << aux->data << " ";        //laço imprimi percorrendo a lista
        aux = aux->prox;
        copy_tam--;
    }
    std::cout << "]" << std::endl;
}

#endif 